-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 14, 2022 at 11:54 AM
-- Server version: 8.0.18
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_info`
--

CREATE TABLE `admin_info` (
  `user` varchar(90) NOT NULL,
  `pass` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_info`
--

INSERT INTO `admin_info` (`user`, `pass`) VALUES
('admin', 'admin@123');

-- --------------------------------------------------------

--
-- Table structure for table `quiz_info`
--

CREATE TABLE `quiz_info` (
  `id` int(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `quizpass` int(255) NOT NULL,
  `timer` bigint(20) NOT NULL,
  `question` text NOT NULL,
  `a` text NOT NULL,
  `b` text NOT NULL,
  `c` text NOT NULL,
  `d` text NOT NULL,
  `answer` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quiz_info`
--

INSERT INTO `quiz_info` (`id`, `department`, `subject`, `year`, `quizpass`, `timer`, `question`, `a`, `b`, `c`, `d`, `answer`) VALUES
(31, 'I.T', 'Internet Technology', 'F.E', 123, 5000, 'qwewqe', '1', '2', '3', '4', '1'),
(32, 'I.T', 'Internet Technology', 'F.E', 1234, 5000, 'ggg', '123', '222', '123', '222', '123'),
(33, 'I.T', 'Internet Technology', 'F.E', 1234, 5000, 'dsasd', '123', '1232', '12', '1212', '12'),
(34, 'I.T', 'Internet Technology', 'F.E', 1234, 5000, 'sdfdsfdsf', '12344', 'eee', 'ddd', 'www', 'www'),
(35, 'I.T', 'Java', 'F.E', 123456, 2000, 'ggsf', '1', '23', '4', '44', '4');

-- --------------------------------------------------------

--
-- Table structure for table `stud_info`
--

CREATE TABLE `stud_info` (
  `id` int(255) NOT NULL,
  `name` varchar(90) NOT NULL,
  `Department` varchar(90) NOT NULL,
  `Year` varchar(90) NOT NULL,
  `moblie` varchar(255) NOT NULL,
  `email` varchar(90) NOT NULL,
  `username` varchar(90) NOT NULL,
  `pass` varchar(90) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stud_info`
--

INSERT INTO `stud_info` (`id`, `name`, `Department`, `Year`, `moblie`, `email`, `username`, `pass`) VALUES
(14, 'gg', 'I.T', 'T.E', '213123123', 'sdsad', 'test', '123'),
(15, 'test3', 'I.T', 'F.E', '1234567', 'test@gmail.com', 'test3', '123');

-- --------------------------------------------------------

--
-- Table structure for table `submit_quiz`
--

CREATE TABLE `submit_quiz` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `correct` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submit_quiz`
--

INSERT INTO `submit_quiz` (`id`, `username`, `subject`, `total`, `correct`) VALUES
(46, 'test3', 'Internet Technology', '3', '2'),
(48, 'saasd', 'Internet Technology', '3', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tech_info`
--

CREATE TABLE `tech_info` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `moblie` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tech_info`
--

INSERT INTO `tech_info` (`id`, `name`, `department`, `subject`, `moblie`, `email`, `user`, `pass`) VALUES
(5, 'test', 'I.T', 'Java', '7972466112', 'test@gmail.com', 'test', '123'),
(6, 'test0', 'Mechanical', 'Internet Technology', '13211', 'test@gmail.com', 'test0', '1234');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `quiz_info`
--
ALTER TABLE `quiz_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stud_info`
--
ALTER TABLE `stud_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user` (`username`);

--
-- Indexes for table `submit_quiz`
--
ALTER TABLE `submit_quiz`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `tech_info`
--
ALTER TABLE `tech_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `quiz_info`
--
ALTER TABLE `quiz_info`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `stud_info`
--
ALTER TABLE `stud_info`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `submit_quiz`
--
ALTER TABLE `submit_quiz`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `tech_info`
--
ALTER TABLE `tech_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
